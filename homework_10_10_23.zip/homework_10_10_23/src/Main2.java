import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {

        /*Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
         которую дал покупатель. Выведите сумму сдачи в виде “X рублей и Y копеек”.
         */
        System.out.println("Введите суммарную стоимость покупок");
        Scanner totalPrice = new Scanner(System.in);
        int skolkoNado = totalPrice.nextInt();
        System.out.println("Введите внесенную сумму покупателем");
        Scanner ammountCash = new Scanner(System.in);
        int skolkoDali = ammountCash.nextInt();
        int sdacha = (skolkoDali -skolkoNado);

        System.out.println("Ваша сдача : " +sdacha);
//не понимаю, как вывести “X рублей и Y копеек”.






    }
}