public class Main {
    public static void main(String[] args) {
        System.out.println("My favourite colour is purple");
        System.out.println(" I have two scientific degree in Chemistry Engineering ");
        System.out.println("Currently living in Germany ");

    }
}