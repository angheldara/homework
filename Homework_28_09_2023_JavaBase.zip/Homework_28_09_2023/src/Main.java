public class Main {
    public static void main(String[] args) {

        System.out.println("Homework 28_09");
        char c = 'G';
        int i = 89;
        byte b = 4;
        short s = 56;
        float f = 4.7333436F;
        double d  = 4.355453532;
        long l = 12121L;

        System.out.println(c);
        System.out.println(i);
        System.out.println(b);
        System.out.println(s);
        System.out.println(f);
        System.out.println(d);
        System.out.println(l);

        /* Дано 3-х значное число.Вывести на экран все цифры этого числа. Пример : 345
        вывод в консоль : число 345 > 3, 4, 5
        987 >9, 8, 7
        */
int mainNumber = 345;
int n1 = mainNumber / 100;
int n2 = mainNumber % 100 / 10;
int n3 = mainNumber % 10;

System.out.println(" Число " + mainNumber+ " -> " + n1 + " , " + n2 + " , " + n3);

        int mainNum = 987;
        int n_1 = mainNum / 100;
        int n_2 = mainNum % 100 / 10;
        int n_3 = mainNum % 10;

        System.out.println(" Число " + mainNum + " -> " + n_1 + " , " + n_2 + " , " + n_3);


 byte by = 14;
System.out.println(by);
System.out.println(by++) ;
 /* Не совсем поняла, что делать с   System.out.println(b); // b++ */

 char ch = 'A';
        System.out.println(ch);
        System.out.println(ch++) ;
     }
}