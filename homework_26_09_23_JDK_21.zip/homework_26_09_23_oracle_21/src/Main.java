public class Main {
    public static void main(String[] args)
    {
        System.out.println("My name is Daria Anghel ");
        System.out.println(" I am "+25+" y.o");
        System.out.println(" I am speaking  "+5+" languages , like Russian, English , Romanian, German and French");
        System.out.println(" I have absolutely no idea which IT specialist will I be , but at this moment I am enjoing the" +
                "process of education");

    }

}