package anniversary;

public enum AnniversaryType {
    CALICO,
    WOODEN,
    TIN,
    CRYSTAL,
    PORCELAIN,
    SILVER,
    PEARL,
    CORAL,
    RUBY,
    SAPHIRE
}
