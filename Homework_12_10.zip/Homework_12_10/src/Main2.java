import java.security.spec.RSAOtherPrimeInfo;
import java.util.Random;
import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
/*Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
 Программа генерирует два целых однозначных числа.
 Программа задаёт вопрос: результат умножения первого числа на второе?
 Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
 Если пользователь ответил неправильно, то программа должна показать правильный ответ.
 */

        Random numbers = new Random();
        int number1 = numbers.nextInt(1,10);
        int number2 = numbers.nextInt(1,10);
        System.out.println(number1 + " умножить на " + number2);
        System.out.println("Результат умножения первого числа на второе? ");
        Scanner number3 = new Scanner(System.in);
        int result =number3.nextInt();
        if (number1 * number2 == result ) {
            System.out.println("Нормально");
        }else {
            System.out.printf( "Правильный ответ %s" , number1 * number2  );
        }





    }


}
