import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {

        /*Пользователь вводит целое число.
         Напишите программу, которая делит это число на 2 и выводит результат.
          Остаток деления можно отбросить.
           Операторы деления  умножения * и остатка от деления % применять нельзя.
         */

        System.out.println("Введите целое число");
        Scanner number = new Scanner(System.in);
        int number1 = number.nextInt();
        int number2 = (number1 >>1);
        System.out.println( "Результат деления " + number2);




    }
}