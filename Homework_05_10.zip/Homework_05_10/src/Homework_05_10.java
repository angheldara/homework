import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;

public class Homework_05_10 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
// 1 Напишите программу, в которой объявите переменные всех примитивных типов.
        // Значение для каждой переменной сгенерируйте с помощью класса Random.
        // При необходимости используйте приведение типов. Полученные значения выведите в консоль.
        //2 В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
        // При необходимости используйте метод String.valueOf().
        // Ограничений на длину строки и содержимое нет. Полученное значение выведите в консоль.
        Random rnd = new Random();
        int i = rnd.nextInt(3645);
        byte b = (byte) rnd.nextInt(125);
        short s = (short) rnd.nextInt(36);
        long l = rnd.nextLong();
        double d = rnd.nextDouble();
        float f = rnd.nextFloat();
        boolean b1 = rnd.nextBoolean();
        System.out.println(i);
        System.out.println(b);
        System.out.println(s);
        System.out.println(l);
        System.out.println(d);
        System.out.println(f);
        System.out.println(b1);
        String number = "117";
        byte boje = Byte.parseByte(String.valueOf((byte)rnd.nextInt(Integer.parseInt(number)))); // все, что касается parse
        // не уверена, можно все одной строкой писать?
        short dai = Short.parseShort(String.valueOf((short)rnd.nextInt(Integer.parseInt(number))));
        int sily = Integer.parseInt(String.valueOf(rnd.nextInt(Integer.parseInt(number))));
        long ponyati = Long.parseLong(String.valueOf(rnd.nextLong(Long.parseLong(number))));
        System.out.println(boje);
        System.out.println(dai);
        System.out.println(sily);
        System.out.println(ponyati);
// Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
// Когда все данные введены, программа должна выдать сообщение:
// «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
// В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.

        Scanner pomogite = new Scanner(System.in); //Scanner  так как у нас ввод данных остается за пользователем?
        System.out.println("Введите имя : ");
        String name = pomogite.nextLine();
        System.out.println("Введите возраст : ");
        int vozrast = pomogite.nextInt();
        System.out.println("Введите вес : ");
        int ves = pomogite.nextInt();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %d килограмм золота.", name, vozrast, ves); // если честно, не понимаю,зачем тут
         // printf , но помню, что он тут нужен

        // Задание 3
        //Напишите программу, которая получает от пользователя два целых числа
        // и затем вычисляет сумму (сложение), разницу (вычитание), произведение (умножение) и частное (деление) введённых чисел.
        // Результат вычислений выведите в консоль.


        Scanner interesno = new Scanner(System.in);
        System.out.println("number1");
        String number1 = interesno.nextLine();
        System.out.println("number2");
        String number2 = interesno.nextLine();
        System.out.println("amount");
        int sum = Integer.parseInt(( number1 + number2 ));
        System.out.println(sum);
        int residual =Integer.parseInt(number1 - number2 );
        System.out.println(residual);
        int multiplication = Integer.parseInt(number1 *number2 );

    }

}