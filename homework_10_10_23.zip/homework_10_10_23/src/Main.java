import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        /*1 уровень сложности: 1 Дана длина в метрах. Напишите программу, которая переводит
         указанное значение в км, мили, футы и аршины.
         Выведите начальное и конвертированные значения на экран.
         */
        System.out.println("Введите длину в метрах");
        Scanner dlina = new Scanner(System.in);
        int choice = dlina.nextInt();
        double km = (double) choice / 1000;
        double miles = (double) choice / 1609;
        double f =  choice *3.281;
        double a = choice *1.40607;
        System.out.println(" Длина в километрах " +km);
        System.out.println(" Длина в милях " +miles);
        System.out.println(" Длина в футах " +f);
        System.out.println(" Длина в аршинах " +a);





    }
}