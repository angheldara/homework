package game;public enum VariantsOfChoice {
}
