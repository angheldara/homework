public class Main {
    public static void main(String[] args) {
/*1 уровень сложности: №1
Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные
 m и n. Числа могут быть, как целочисленные, так и дробные.
Например :
ввод : m=7, n=11
вывод: Число 11 ближе к 10.
 */
        int n = 13;
        int m = 47;
        int distN = Math.abs(10-n);
        int distM = Math.abs(10-m);
        if (n > m) {
            System.out.println("Ближайщее число к 10 = " + m);
        } else {
            System.out.println("Ближайшее число к 10 = " + n);
        }
    }


}
