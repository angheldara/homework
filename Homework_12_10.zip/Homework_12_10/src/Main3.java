import java.util.Random;
import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
/*Элвис Пресли жил с 1935 по 1977 год.
Используя тернарные операторы, напишите программу,
в которой пользователь вводит год.
Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
 Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»
 */
        Scanner year = new Scanner(System.in);
        System.out.println(" Введите год рождения: ");
        int period = year.nextInt();
        if (period < 1935) {
            System.out.println("Элвис ещё не родился");
            return;
        }
        String whichyear = period < 1935 ? "Элвис ещё не родился" :
                (period >= 1935 && period <= 1977) ? "Элвис жив!": "Элвис навсегда в наших сердцах!";
        System.out.println(whichyear);
    }


}




